const fs = require('fs');
const path = require('path');

const pagesDir = path.join(__dirname, 'sample/pi-sdk-docs-firecrawl/pages');
const docsDir = path.join(__dirname, 'docs');

const docsConfig = {
  primaryNav: [
    { id: "build-first-app", label: "Build your first Pi app" },
    { id: "authenticate-user", label: "Authenticate a user" },
    { id: "accept-payment", label: "Accept a payment" },
    { id: "setup-ads", label: "Set up ads" },
    { id: "use-native-features", label: "Use Pi native features" },
  ],
  secondaryNav: [
    { id: "api-reference", label: "API Reference" },
    { id: "concepts", label: "Concepts" },
    { id: "troubleshooting", label: "Troubleshooting" },
  ]
};

const contentMapping = {
  "build-first-app": [
    "/",
    "/GettingStarted",
    "/getting-started/Register",
    "/getting-started/RegisterApp",
    "/getting-started/Sandbox",
    "/getting-started/Production",
    "/getting-started/MainnetListing",
    "/quick-start/NextJS",
    "/quick-start/React",
    "/quick-start/JavaScript",
    "/quick-start/Express",
    "/quick-start/Rails",
    "/quick-start/Django",
    "/getting-started/Brainstorm",
  ],
  "authenticate-user": ["/platform/Authentication", "/quick-start/genai/Authentication", "/pitopics/AccessToken"],
  "accept-payment": [
    "/platform/Payments",
    "/platform/PaymentsAdvanced",
    "/quick-start/genai/Payments",
    "/pitopics/pipayments/DevPayFlow",
    "/pitopics/PiPayments",
    "/pitopics/pipayments/PiWallet",
    "/pitopics/pipayments/VideoInt",
  ],
  "setup-ads": ["/pi-sdk/Ads", "/platform/Ads"],
  "use-native-features": ["/pi-sdk/Wallet", "/pi-sdk/Utilities", "/pitopics/ChatRooms", "/platform/Tokens", "/platform/PiNet", "/pitopics/PiNet"],
  "api-reference": ["/platform/PlatformAPI", "/platform/SdkReference", "/PiSDK", "/pi-sdk/Core"],
  "concepts": ["/PiTopics", "/Purpose", "/License", "/Launch", "/pitopics/MainVsTest", "/quick-start/genai/GenAISupport"],
  "troubleshooting": ["/CommonMistakes", "/CommunitySupport", "/link", "/quick-start/genai/link"],
};

// Clean docs dir
fs.rmSync(docsDir, { recursive: true, force: true });
fs.mkdirSync(docsDir, { recursive: true });

let sectionIndex = 1;
const allNav = [...docsConfig.primaryNav, ...docsConfig.secondaryNav];
const allFiles = fs.readdirSync(pagesDir).filter(f => f.endsWith('.md'));
const processedFiles = new Set();

for (const nav of allNav) {
  const folderName = `${sectionIndex}-${nav.id}`;
  const sectionDir = path.join(docsDir, folderName);
  fs.mkdirSync(sectionDir, { recursive: true });

  fs.writeFileSync(path.join(sectionDir, '_category_.json'), JSON.stringify({
    label: nav.label,
    position: sectionIndex,
  }, null, 2));

  sectionIndex++;

  const urls = contentMapping[nav.id] || [];
  
  let pageIndex = 1;
  for (const url of urls) {
    const expectedSource = url === '/' 
      ? 'https://pi-apps.github.io/pi-sdk-docs/' 
      : `https://pi-apps.github.io/pi-sdk-docs${url}`;
      
    let foundFile = null;
    let foundContent = null;
    let title = null;

    for (const f of allFiles) {
      if (processedFiles.has(f)) continue;
      
      const p = path.join(pagesDir, f);
      // Read content and replace literal \n with actual newlines to fix scraper output
      let rawContent = fs.readFileSync(p, 'utf-8');
      rawContent = rawContent.replace(/\\n/g, '\n');
      const lines = rawContent.split('\n');
      
      const sourceLine = lines.find(l => l.startsWith('- Source:'));
      if (sourceLine) {
        let sourceUrl = sourceLine.replace('- Source:', '').trim();
        if (sourceUrl.endsWith('/') && sourceUrl !== 'https://pi-apps.github.io/pi-sdk-docs/') {
            sourceUrl = sourceUrl.slice(0, -1);
        }
        let testExpected = expectedSource;
        if (testExpected.endsWith('/') && testExpected !== 'https://pi-apps.github.io/pi-sdk-docs/') {
            testExpected = testExpected.slice(0, -1);
        }

        if (sourceUrl === testExpected) {
          foundFile = f;
          foundContent = rawContent;
          const titleLine = lines.find(l => l.startsWith('- Title:'));
          if (titleLine) {
             title = titleLine.replace('- Title:', '').trim();
          }
          break;
        }
      }
    }

    if (foundFile) {
       processedFiles.add(foundFile);
       const lines = foundContent.split('\n');
       
       let actualStartIdx = 0;
       if (lines[0].startsWith('# ')) actualStartIdx = 1;
       if (lines[1] === '') actualStartIdx = 2;
       
       const cleanLines = lines.slice(actualStartIdx).filter(l => !l.startsWith('- Source:') && !l.startsWith('- Title:'));
       
       const frontmatter = `---
title: "${title || 'Doc'}"
sidebar_position: ${pageIndex}
---
`;
       
       let finalContent = frontmatter + cleanLines.join('\n');
       
       const safeName = url === '/' ? 'index.md' : url.split('/').pop() + '.md';
       fs.writeFileSync(path.join(sectionDir, safeName), finalContent);
       pageIndex++;
    }
  }
}

// Any unprocessed files?
const unprocessedDir = path.join(docsDir, '99-uncategorized');
let createdUnprocessed = false;

for (const f of allFiles) {
  if (!processedFiles.has(f)) {
    if (!createdUnprocessed) {
      fs.mkdirSync(unprocessedDir, { recursive: true });
      fs.writeFileSync(path.join(unprocessedDir, '_category_.json'), JSON.stringify({
        label: "Other",
        position: 99,
      }, null, 2));
      createdUnprocessed = true;
    }
    const p = path.join(pagesDir, f);
    let rawContent = fs.readFileSync(p, 'utf-8');
    rawContent = rawContent.replace(/\\n/g, '\n');
    const lines = rawContent.split('\n');
    let title = "Uncategorized Doc";
    const titleLine = lines.find(l => l.startsWith('- Title:'));
    if (titleLine) {
       title = titleLine.replace('- Title:', '').trim();
    }
    
    let actualStartIdx = 0;
    if (lines[0].startsWith('# ')) actualStartIdx = 1;
    if (lines[1] === '') actualStartIdx = 2;
    const cleanLines = lines.slice(actualStartIdx).filter(l => !l.startsWith('- Source:') && !l.startsWith('- Title:'));
    
    const frontmatter = `---
title: "${title}"
---
`;
    fs.writeFileSync(path.join(unprocessedDir, f.replace('https-pi-apps.github.io-pi-sdk-docs-', '')), frontmatter + cleanLines.join('\n'));
  }
}
console.log("Migration complete.");
