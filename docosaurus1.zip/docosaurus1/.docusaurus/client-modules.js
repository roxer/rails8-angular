export default [
  require("/Users/roxer/code/pi/my-website22/.docusaurus/docusaurus-plugin-css-cascade-layers/default/layers.css"),
  require("/Users/roxer/code/pi/my-website22/node_modules/infima/dist/css/default/default.css"),
  require("/Users/roxer/code/pi/my-website22/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/Users/roxer/code/pi/my-website22/node_modules/@docusaurus/theme-classic/lib/nprogress"),
  require("/Users/roxer/code/pi/my-website22/src/css/custom.css"),
];
