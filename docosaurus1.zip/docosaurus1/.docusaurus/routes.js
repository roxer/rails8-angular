import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/blog',
    component: ComponentCreator('/blog', 'e21'),
    exact: true
  },
  {
    path: '/blog/archive',
    component: ComponentCreator('/blog/archive', '182'),
    exact: true
  },
  {
    path: '/blog/authors',
    component: ComponentCreator('/blog/authors', '0b7'),
    exact: true
  },
  {
    path: '/blog/authors/all-sebastien-lorber-articles',
    component: ComponentCreator('/blog/authors/all-sebastien-lorber-articles', 'ec3'),
    exact: true
  },
  {
    path: '/blog/authors/yangshun',
    component: ComponentCreator('/blog/authors/yangshun', 'b14'),
    exact: true
  },
  {
    path: '/blog/first-blog-post',
    component: ComponentCreator('/blog/first-blog-post', '5c7'),
    exact: true
  },
  {
    path: '/blog/long-blog-post',
    component: ComponentCreator('/blog/long-blog-post', '4f6'),
    exact: true
  },
  {
    path: '/blog/mdx-blog-post',
    component: ComponentCreator('/blog/mdx-blog-post', 'e9f'),
    exact: true
  },
  {
    path: '/blog/tags',
    component: ComponentCreator('/blog/tags', '287'),
    exact: true
  },
  {
    path: '/blog/tags/docusaurus',
    component: ComponentCreator('/blog/tags/docusaurus', '096'),
    exact: true
  },
  {
    path: '/blog/tags/facebook',
    component: ComponentCreator('/blog/tags/facebook', '394'),
    exact: true
  },
  {
    path: '/blog/tags/hello',
    component: ComponentCreator('/blog/tags/hello', '731'),
    exact: true
  },
  {
    path: '/blog/tags/hola',
    component: ComponentCreator('/blog/tags/hola', '4fa'),
    exact: true
  },
  {
    path: '/blog/welcome',
    component: ComponentCreator('/blog/welcome', 'dfe'),
    exact: true
  },
  {
    path: '/helloMarkdown',
    component: ComponentCreator('/helloMarkdown', '966'),
    exact: true
  },
  {
    path: '/helloReact',
    component: ComponentCreator('/helloReact', '77a'),
    exact: true
  },
  {
    path: '/markdown-page',
    component: ComponentCreator('/markdown-page', '53a'),
    exact: true
  },
  {
    path: '/docs',
    component: ComponentCreator('/docs', '12c'),
    routes: [
      {
        path: '/docs',
        component: ComponentCreator('/docs', '0a3'),
        routes: [
          {
            path: '/docs',
            component: ComponentCreator('/docs', '0d7'),
            routes: [
              {
                path: '/docs/accept-payment/DevPayFlow',
                component: ComponentCreator('/docs/accept-payment/DevPayFlow', '25f'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/accept-payment/Payments',
                component: ComponentCreator('/docs/accept-payment/Payments', '649'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/accept-payment/PaymentsAdvanced',
                component: ComponentCreator('/docs/accept-payment/PaymentsAdvanced', 'fe8'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/accept-payment/PiPayments',
                component: ComponentCreator('/docs/accept-payment/PiPayments', '3f1'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/accept-payment/PiWallet',
                component: ComponentCreator('/docs/accept-payment/PiWallet', '79f'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/accept-payment/VideoInt',
                component: ComponentCreator('/docs/accept-payment/VideoInt', '1aa'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/api-reference/Core',
                component: ComponentCreator('/docs/api-reference/Core', '1f2'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/api-reference/PiSDK',
                component: ComponentCreator('/docs/api-reference/PiSDK', 'e72'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/api-reference/PlatformAPI',
                component: ComponentCreator('/docs/api-reference/PlatformAPI', '589'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/api-reference/SdkReference',
                component: ComponentCreator('/docs/api-reference/SdkReference', '001'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/authenticate-user/AccessToken',
                component: ComponentCreator('/docs/authenticate-user/AccessToken', 'ee9'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/authenticate-user/Authentication',
                component: ComponentCreator('/docs/authenticate-user/Authentication', 'fd8'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/',
                component: ComponentCreator('/docs/build-first-app/', '1c5'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/Brainstorm',
                component: ComponentCreator('/docs/build-first-app/Brainstorm', '691'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/Django',
                component: ComponentCreator('/docs/build-first-app/Django', '941'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/Express',
                component: ComponentCreator('/docs/build-first-app/Express', '635'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/GettingStarted',
                component: ComponentCreator('/docs/build-first-app/GettingStarted', 'a7d'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/JavaScript',
                component: ComponentCreator('/docs/build-first-app/JavaScript', 'edc'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/MainnetListing',
                component: ComponentCreator('/docs/build-first-app/MainnetListing', '220'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/NextJS',
                component: ComponentCreator('/docs/build-first-app/NextJS', 'a15'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/Production',
                component: ComponentCreator('/docs/build-first-app/Production', '456'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/Rails',
                component: ComponentCreator('/docs/build-first-app/Rails', '020'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/React',
                component: ComponentCreator('/docs/build-first-app/React', 'ea9'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/Register',
                component: ComponentCreator('/docs/build-first-app/Register', '357'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/RegisterApp',
                component: ComponentCreator('/docs/build-first-app/RegisterApp', '11d'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/build-first-app/Sandbox',
                component: ComponentCreator('/docs/build-first-app/Sandbox', '660'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/concepts/GenAISupport',
                component: ComponentCreator('/docs/concepts/GenAISupport', '6e3'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/concepts/Launch',
                component: ComponentCreator('/docs/concepts/Launch', 'b03'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/concepts/License',
                component: ComponentCreator('/docs/concepts/License', 'a47'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/concepts/MainVsTest',
                component: ComponentCreator('/docs/concepts/MainVsTest', '5c0'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/concepts/PiTopics',
                component: ComponentCreator('/docs/concepts/PiTopics', '1c5'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/concepts/Purpose',
                component: ComponentCreator('/docs/concepts/Purpose', '088'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/setup-ads/Ads',
                component: ComponentCreator('/docs/setup-ads/Ads', 'b8b'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/troubleshooting/CommonMistakes',
                component: ComponentCreator('/docs/troubleshooting/CommonMistakes', 'b3c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/troubleshooting/CommunitySupport',
                component: ComponentCreator('/docs/troubleshooting/CommunitySupport', 'ebd'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/troubleshooting/link',
                component: ComponentCreator('/docs/troubleshooting/link', 'd13'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/uncategorized/Platform',
                component: ComponentCreator('/docs/uncategorized/Platform', '310'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/uncategorized/platform-DeveloperPortal',
                component: ComponentCreator('/docs/uncategorized/platform-DeveloperPortal', 'e4d'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/uncategorized/QuickStart',
                component: ComponentCreator('/docs/uncategorized/QuickStart', 'e4a'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/use-native-features/ChatRooms',
                component: ComponentCreator('/docs/use-native-features/ChatRooms', 'fae'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/use-native-features/PiNet',
                component: ComponentCreator('/docs/use-native-features/PiNet', '817'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/use-native-features/Tokens',
                component: ComponentCreator('/docs/use-native-features/Tokens', 'ec5'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/use-native-features/Utilities',
                component: ComponentCreator('/docs/use-native-features/Utilities', 'd10'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/use-native-features/Wallet',
                component: ComponentCreator('/docs/use-native-features/Wallet', 'c9d'),
                exact: true,
                sidebar: "tutorialSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/',
    component: ComponentCreator('/', 'e5f'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
