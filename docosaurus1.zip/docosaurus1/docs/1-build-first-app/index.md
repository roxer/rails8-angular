---
title: "Home"
sidebar_position: 1
---

# Welcome to the Pi Network SDK Documentation

The Pi Network SDK is the gateway for developers to build decentralized applications (Pi Apps) that integrate seamlessly with the Pi Ecosystem. By leveraging this SDK, you can create web applications that interact with the Pi Blockchain, authenticate millions of Pioneers, and facilitate secure cryptocurrency transactions within the Pi Browser.

# Pi’s Vision

Pi’s vision is to build the world’s most inclusive peer-to-peer ecosystem and online experience, fueled by Pi, the world’s most widely used cryptocurrency.

Pi delivers on the true promise of blockchain: a massive, accessible, and open community powered by the world’s most widely distributed cryptocurrency that enables a robust ecosystem for members, merchants and developers alike. Founded in 2018 by a team of early innovators in blockchain and social computing, with PhDs from Stanford University, Pi Network is a utilities-based ecosystem for third-party apps on a mobile web platform, with widespread (rather than concentrated) token distribution. The blockchain platform offers a mobile-first mining approach, with low financial cost and a light environmental footprint within the crypto space. The community boasts an engaged 60M+ members in over 230 countries or regions.

# What is the Pi SDK?

The Pi SDK is a suite of development tools and APIs designed to abstract the complexities of blockchain interaction. It allows you to build “Pi-native” experiences where users can use their Pi identity and balance without leaving your application.

Key capabilities include:

- User Authentication: Securely sign in users using their Pi Network accounts.
- Payments (U2A & A2U): Facilitate User-to-App (U2A) payments for services or App-to-User (A2U) payments for rewards and withdrawals.
- Platform Integration: Access Pi-specific features like the Pi Wallet and standardized UI components.

## Documentation Structure

To help you navigate the development lifecycle, this site is organized into three primary sections:

### [Getting Started](https://pi-apps.github.io/pi-sdk-docs/GettingStarted)

New to the ecosystem? Start here to understand the
foundational requirements. There you will find checklists for setting
up your developer account and registering your first app in the Pi
Developer Portal. You will also find instructions on how to use the Pi
Sandbox to test your application in a local desktop browser before
deploying to the Pi Browser.

### [Quick Start](https://pi-apps.github.io/pi-sdk-docs/QuickStart)

Once you have activated your account and registered your app, you can
take advantage of our software packages that simplify the setup
process. All of the “Ten Minutes to Transaction” packages provide an
installation script that creates a “buy” button for initiating a Pi
transaction. We support a range of frameworks including Express,
Django, and Rails for the backend and React, Stimulus, and raw
JavaScript for the frontend.

### [Core SDK (JavaScript)](https://pi-apps.github.io/pi-sdk-docs/PiSDK)

This is the core library for your client-side application. It enables
the `window.Pi` object, which serves as the bridge between your
web app and the Pi Browser.

Topics include:

- [Installation](https://pi-apps.github.io/pi-sdk-docs/PiSDK#installation): How to include the SDK script tag in your HTML.
- [Authentication](https://pi-apps.github.io/pi-sdk-docs/pi-sdk/Core#initialization--authentication): Detailed guides on requesting user “scopes” (like usernames) and handling authorization.
- [Payments](https://pi-apps.github.io/pi-sdk-docs/pi-sdk/Core#payment-flow): Interfacing with the `createPayment` method and managing the lifecycle of a transaction.
- And more!

### [Backend & API Reference](https://pi-apps.github.io/pi-sdk-docs/Platform)

Building a secure app requires server-side validation.

Topics include:

- [Platform API](https://pi-apps.github.io/pi-sdk-docs/platform/PlatformAPI): Endpoint reference for your backend (e.g. `GET /me`, payment approval/completion, A2U payments, rewarded-ad verification).
- [Payments](https://pi-apps.github.io/pi-sdk-docs/platform/Payments): Conceptual guide to the “Double-Check” flow (server-side approval + completion) for validating User-to-App transactions.
- And more!

## Whitepaper

The [Original Pi Whitepaper](https://minepi.com/white-paper) was published on PiDay, March 14, 2019. While our original vision remains unchanged, the details of this whitepaper are not fully up to date. On December 28, 2021, along with the release of the Enclosed mainnet, we published three draft chapters of the [Updated Whitepaper](https://medium.com/@pinetwork-official/pi-whitepaper-chapters-mainnet-token-model-mining-and-roadmap-19f4a6774e71), detailing the Pi token token model and mining mechanism as well as the project’s roadmap.

## Key Resources

- [Developer Portal](https://pi-apps.github.io/pi-sdk-docs/platform/DeveloperPortal): Access this via the Pi Browser to register your app and manage your API keys.
- [Demo App](https://github.com/pi-apps/demo): A complete, open-source reference implementation to see the SDK in action.
- [PiOS](https://github.com/pi-apps/PiOS) (Pi Open Source): Learn how to contribute to the community and use Pi-licensed code for your own projects.

## Ready to build?

Jump straight into the [Getting Started Guide](https://pi-apps.github.io/pi-sdk-docs/GettingStarted) to register your app and begin your journey into the Pi Network ecosystem!

## Developer Terms of Service

By accessing or using any part of the Pi Network Developer tools and resources, you agree that you are subject to and will comply with the [Pi Network Developer Terms of Use](https://socialchain.app/developer_terms).
