---
title: "Mainnet Listing Requirements"
sidebar_position: 14
---

# Brainstorm

## Introduction

Brainstorm is an app to connect with other developers, join projects, share ideas, and participate in Pi Network’s ongoing hackathon. The [Ongoing Hackathon](https://minepi.com/developers/pi-hackathon/) page on our website details what it is and how to participate.

## Pi Brainstorm

The Pi Brainstorm application is designed to be the hub where Pioneers can collaborate and propose ideas for new apps that will build utility in the Pi Ecosystem. All Pioneers are able to view, propose, and apply to join existing projects within the Brainstorm app.

Check it out by clicking on the Brainstorm tile within the Pi Browser. Listing your app on the Brainstorm brings you visibility to the Core Team and the community, and can potentially attract other community members with a variety of skills to apply to work on your team.

The Brainstorm app is the hub for Hackathons within Pi Network. The Brainstorm app hosts all of the steps and information for the Ongoing Hackathon. The ongoing Hackathon system is meant to further surface excellent community development and support the overall apps ecosystem.
