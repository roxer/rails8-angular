---
title: "Account Registration"
sidebar_position: 3
---

# Account Registration

The first step in your Pi journey is to register an account with Pi
Network. You will need to download the Pi app and Pi Browser app onto
your device. The registration process includes verifying your email
address.

## Create Your Account and Complete Initial Setup

1. Download the Pi App
   - [Google Play Store Link](https://play.google.com/store/apps/details?id=com.blockchainvault)
   - [Apple App Store Link](https://itunes.apple.com/us/app/pi-network/id1445472541)
2. Register for an account
   - Use a referral code if you have one. You can sign up without a code, but you will receive 1 Pi if you sign up with a code.
3. Download and sign in to Pi Browser
   - See our [video tutorial](https://youtu.be/q8R_-R8Wkls?t=64) to learn how to complete this step.
   - [Google Play Store Link](https://play.google.com/store/apps/details?id=pi.browser)
   - [Apple App Store Link](https://apps.apple.com/us/app/pi-browser/id1560911608)
4. Verify your email address (required before registering apps)


   - Open the Pi app and tap the ‘☰’ (hamburger menu) in the top-left corner.

![Hamburger menu button](https://pi-apps.github.io/pi-sdk-docs/getting-started/img/HamburgerButton.png)

   - Select Profile.

![Profile button](https://pi-apps.github.io/pi-sdk-docs/getting-started/img/ProfileButton.png)

   - Confirm your email address.

![Email button](https://pi-apps.github.io/pi-sdk-docs/getting-started/img/EmailButton.png)![Email address confirmation](https://pi-apps.github.io/pi-sdk-docs/getting-started/img/EmailAddress.png)

5. Use Pi Browser to explore available apps in the Pi ecosystem.
