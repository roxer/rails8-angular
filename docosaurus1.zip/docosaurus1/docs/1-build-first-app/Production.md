---
title: "Production App Access"
sidebar_position: 6
---

# Production App Access

1. Deploy your app in a production environment
   - Enter the desired Production URL. This is the URL the app will be accessible from within the pi browser.
2. Validate Domain Ownership
   - Prove ownership of your domain by adding the provided validation key to a .txt file named ‘validation-key.txt’ and place it on your hosting domain. Click on the step to get your validation key and URL to place the file.
3. Process a transaction on your app
   - Have your app process a User-to-App Pi Transaction to confirm you have successfully connected to the Pi Ecosystem.
