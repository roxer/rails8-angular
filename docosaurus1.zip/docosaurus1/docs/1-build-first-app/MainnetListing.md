---
title: "Mainnet Listing Requirements"
sidebar_position: 7
---

# Mainnet Listing Requirements

The Ecosystem interface on the Pi Browser, a platform to showcase the utilities built by Pi developers and connect them with Pi’s vibrant network of over 60 million engaged Pioneers, features a dynamic directory of Mainnet and Testnet apps. This interface offers Pioneers an easy way to discover and interact with many Pi apps.

To be eligible for listing in the Mainnet Ecosystem Interface, apps must adhere to Pi Ecosystem standards and requirements. While developers are free to design their own UIs, the Pi Ecosystem only lists apps that align with Pi’s ecosystem principles—such as maintaining a seamless user experience within Pi and not simply acting as funnels to external platforms. There is nothing inherently wrong with external links or alternative designs, but the Pi Ecosystem prioritizes apps that contribute meaningfully to the network’s growth and utility. Many apps that do not get listed simply result from a misunderstanding of these expectations, rather than outright rejection.

This page will outline the key listing criteria, clarify common misconceptions, and provide guidance on how to meet the standards. If your app meets the criteria, it may be listed. If it does not, it will remain outside the Ecosystem Listing.

## Deliver a Fully Functional App with a Professional UI

Your app must be fully operational with a clean, user-friendly interface. All interactive elements should function correctly for a seamless experience. A polished UI improves user trust and engagement.

## Complete KYC Verification

Developers must complete KYC to verify their identity before submitting an application to list. This safeguards the Pi Ecosystem by seeking to prevent fraudulent actors. While KYC cannot fully prevent a developer from acting maliciously, it may reduce that risk, and also serves to provide a reference point for their identity in case of disputes. The Pi KYC app does not verify an app’s legitimacy; it simply confirms that the developers have submitted their identification documents, which have been reviewed and approved by validators.

## Avoid Trademark Violations

Your app’s URL/domain must not start with “pi” or misuse Pi branding. Avoid using Pi’s official logo, colors, or design elements. Maintaining unique branding prevents confusion and legal issues. Please read Pi Trademark Usage Guideline Blog for more details.

| Compliant | Non-compliant |
| --- | --- |
| https://www.bananas.com | https://www.pibananas.com |

## Use Only Pi Authentication

Apps must integrate Pi’s Authentication SDK for user logins. Other login methods, such as email or third-party accounts, are prohibited. This ensures a secure and standardized authentication process.

## Pi-Only Transactions

All transactions must be conducted in Pi, with no support for non-Pi Tokens or fiat currencies. This will help the Pi ecosystem and community showcase its utility while protecting users.

## Avoid Redirection to External Sites

Apps should not redirect users to external websites, apps or services. Keeping users within the ecosystem enhances security and trust. External links increase risks like phishing and scams. Redirection to external services will be evaluated on a case-by-case basis, based on their absolute necessity.

## Limit Data Collection

Only collect user data essential for your app’s functionality. Unnecessary collection of personal information, like emails or phone numbers, is prohibited unless required for the app’s functionality. This ensures there are clear data policies which help maintain user privacy and compliance.

* * *

Developing Mainnet-compliant applications is more than just meeting technical requirements. It is also about maintaining a trustworthy, innovative, and sustainable ecosystem that reflects the values of Pi Network. By adhering to these guidelines, developers can ensure their applications can stand out as reliable and high-quality contributions to the Pi Community. By prioritizing these principles, your application can unlock unique opportunities for Pioneers worldwide. Let’s work together to provide applications that inspire trust, and showcase the incredible potential of Pi
