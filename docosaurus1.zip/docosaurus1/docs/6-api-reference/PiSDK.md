---
title: "Pi SDK"
sidebar_position: 3
---

# Pi Network JavaScript SDK (frontend)

The Pi JavaScript SDK is the **frontend** SDK for Pi Apps. It runs in the **Pi Browser** and exposes a global `window.Pi` object for authentication, payments, ads, wallet features, and other native integrations.

If you’re looking for backend REST endpoints (approve/complete payments, `/me`, and rewarded ad verification), see **[Platform APIs](https://pi-apps.github.io/pi-sdk-docs/Platform)**.

**This SDK documentation is provided for completeness. We recommend that developers**
**use helper packages (`pi-sdk-*`) instead of calling the global SDK directly.**
**Use this library directly only as a last resort.**

* * *

## Prerequisites

- **Register your app** in the Pi Developer Portal (in Pi Browser): `pi://develop.pinet.com`
- (Recommended) Use the **Pi Sandbox** during development: **[Sandbox Development](https://pi-apps.github.io/pi-sdk-docs/getting-started/Sandbox)**

## Installation

Load the Pi SDK script (recommended inside your document `<head>`):

HTML


```html
<head>
  <!-- ... other <head> content (meta, title, styles, etc.) ... -->
  <script src="https://sdk.minepi.com/pi-sdk.js"></script>
</head>
```

Then initialize it once on page load:

HTML


```html
<script>
  Pi.init({ version: "2.0", sandbox: true });
</script>
```

> If you’re using one of the Quick Start packages or helper SDKs, initialization may be handled for you.

## Global access

After loading `pi-sdk.js`, the main SDK instance is available as **`window.Pi`**.

## Where to go next

### [Core](https://pi-apps.github.io/pi-sdk-docs/pi-sdk/Core)

Authentication (`Pi.authenticate`) and the client-side portion of the payment flow (`Pi.createPayment`).

### [Ads](https://pi-apps.github.io/pi-sdk-docs/pi-sdk/Ads)

Use `window.Pi.Ads` to show interstitial/rewarded ads. For rewarded ads, your backend should verify status via the Platform API before granting rewards.

### [Utilities & native features](https://pi-apps.github.io/pi-sdk-docs/pi-sdk/Utilities)

Share dialog, native features list, permissions, clipboard, QR scanning, and more.

## Full method reference

For a complete list of methods and signatures, see **[Client SDK reference](https://pi-apps.github.io/pi-sdk-docs/platform/SdkReference)**.
