---
title: "PiNet"
sidebar_position: 6
---

# Pi Net

Is a platform that allows anyone to browse, view and share select Pi Apps on any browser of their choice and on any device, bridging the gap between the Web2 and Web3 world and improving accessibility to the Pi ecosystem for Pioneers and non-Pioneers alike.

## What Is PiNet

For developers, share and show your app through PiNet to onboard non-Pioneer users to your app. Nearly any Mainnet Ecosystem app found on the Pi Browser now has the potential to be accessible on Chrome, Safari, Brave, and any other conventional internet browser that conforms to the standard http protocol.

PiNet achieves this by giving Pi applications a unique URL which can be accessed by anyone through PiNet in the Browser of their choice.

## To Create a PiNet URL

There are a few steps that need completed in order to register for and allow users to start using your application through a PiNet URL.

**To be eligible to register for a PiNet URL the application must be listed in the Ecosystem App.**

1. The application needs to register for a PiNet subdomain within the Developer Portal.

2. On the Application Checklist in the Developer Portal there is a step for adding a “PiNet Subdomain”


   - Complete this field with the subdomain that is desired by the application for Pioneers to access the application.

   - Use a subdomain of the previously Verified App Domain
   - A random 4-5 digit number will be added to the URL in order to prevent Domain Squatting. In the future, it may be possible to drop the numbers
      \\\\* Example:
   - Subdomain - AppExample.com
   - PiNet URL - AppExample12345.pinet.com
      \\\\* All URLs must comply with the Pi Trademark Guidelines
3. At this stage the application is ready to start sharing its PiNet URL with users.

## PiNet User Flow

While the PiNet user may view Pi apps without logging into their Pi account, the user will be blocked from the application at the point in the application where the Pi SDK is required for interaction. This means that once the application invokes Pi.authenticate the user’s experience will end. They will need to either access the application from the Pi Browser and, if they don’t already have an account, they will need to create one, in order to continue experiencing the application.

- For example, when designing Fireside Forum, the application was built so that those visiting from the PiNet URL can click on and view posts and comments. A user, however, is required to use the Pi-Browser if they want to create a post or add any fire. These actions require the user to log into the Fireside Forum application and submit a transaction.

- Other examples are:
  - Marketplace apps could allow PiNet URLs to view offerings but require Pi Account to make a purchase
  - Games could allow a user to complete a tutorial, to see the game, prior to requiring the user to authenticate.
- Applications that invoke the Pi.Authenticate method of the Pi SDK, when a user first visits the app, will need to restructure their applications’ user flow to allow for users to visit without initially requiring Pi account authentication
  - Applications that utilize a landing page which blocks access to the app from outside of the Pi Browser will be unable to use PiNet until this landing page is removed or refactored.
