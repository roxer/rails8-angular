---
title: "Pi Wallet"
sidebar_position: 1
---

# Pi Network Wallets

The Pi Network JS SDK exposes wallet-related operations and blockchain
interactions via the `window.Pi.Wallet` module. These methods enable
your app to create, submit, and inspect Pi blockchain transactions for
authenticated users, only within the Pi Browser.

This guide demonstrates how to integrate the Pi SDK into
many application frameworks.
This example shows how to initialize the Pi SDK, authenticate a Pioneer, and
create a payment request inside a Pi app.

The `pi-sdk-js`
package
is part of the “Ten Minutes to Transactions” effort described in this
[video](https://www.youtube.com/watch?v=cIFqf1Z5pRM&t).

If you, or your GenAI agent, are planning to use the
Pi SDK modules in this documentation
for your app, it is highly suggested that you use this
package
rather than implement transaction processing by hand with the core Pi SDK. The three way handshake between client, server, and the Pi servers required is provded for you.

Note: Pi SDK authentication and payment features require the application to run inside the Pi Browser.

* * *

## Purpose

- Enable wallet-related operations and blockchain interactions in the Pi Browser
- Create, submit, and inspect Pi blockchain transactions within the Pi Browser

* * *

## Overview

- **Purpose:** Wallet-related operations and access.
- **Example available (functions may differ by SDK version):**

JavaScript


```javascript
window.Pi.Wallet.submitTransaction(xdr)
window.Pi.Wallet.getUserMigratedWalletAddresses()
```

- All methods are Promise-based.

* * *

## `window.Pi.Wallet` Methods

### `.submitTransaction(xdr)`

- **Purpose:** Submits a pre-signed Stellar XDR transaction to the Pi Blockchain via the user’s authenticated wallet.
- **Parameters:**
  - `xdr` (string): Base64-encoded [Stellar XDR](https://developers.stellar.org/docs/glossary/xdr) representing the transaction
- **Returns:**
  - `Promise<object>`: Resolved with the blockchain transaction result if success, or rejects on error (user cancel, auth problem, RPC failure, etc.).
- **Example:**

JavaScript


```javascript
Pi.Wallet.submitTransaction(xdr).then(function(result) {
  // Transaction submitted! Process result or notify user
}).catch(function(error) {
  // Submission failed; handle error
});
```

* * *

### `Pi.Wallet.getUserMigratedWalletAddresses()`

- **Purpose:** Returns a list of wallet addresses controlled by the user (mainnet and/or testnet, as migrated from Pi Network). Useful for apps needing to display blockchain identity details.
- **Returns:**
  - `Promise<object>`: An object with a `wallets` array, each containing `{ publicKey: string }`.
- **Example:**

JavaScript


```javascript
Pi.Wallet.getUserMigratedWalletAddresses().then(function(data) {
  data.wallets.forEach(function(wallet) {
    console.log('Wallet address:', wallet.publicKey);
  });
});
```

* * *

## **Typical Usage Pattern**

JavaScript


```javascript
// Submit an existing signed transaction
const signedXDR = "AAAA...";
Pi.Wallet.submitTransaction(signedXDR)
  .then(txResult => { console.log("Tx Success!", txResult); })
  .catch(err => { alert("Tx failed: " + err.message); });

// Get user's wallet addresses
Pi.Wallet.getUserMigratedWalletAddresses()
  .then(data => {
    // [{ publicKey: "G..." } ...]
    doSomething(data.wallets);
});
```

* * *

## **Additional Notes & Best Practices**

- Only call Wallet methods after user authentication (`Pi.authenticate(...)`).
- Transactions must be pre-signed; the SDK does not build or sign transactions for you. See [Stellar docs](https://developers.stellar.org/docs/tools/lab/transactions) on creating XDR.
- Always handle errors: the user may cancel, reject, or lose connection, or the transaction might fail at the blockchain layer.
- Use `.getUserMigratedWalletAddresses()` to display or confirm available wallet addresses for advanced flows.
- **Advanced:** For custom flows (advanced custody, app-to-user payments, etc.) see the [advanced payments](https://pi-apps.github.io/pi-sdk-docs/platform/PaymentsAdvanced) and [SDK reference](https://pi-apps.github.io/pi-sdk-docs/platform/SdkReference#wallet).

* * *

## **References**

- [Advanced Pi Payments](https://pi-apps.github.io/pi-sdk-docs/platform/PaymentsAdvanced)
- [Stellar Transaction XDR](https://developers.stellar.org/docs/glossary/xdr)
