---
title: "Public Chat Rooms"
sidebar_position: 3
---

# Chat Rooms for Community Apps

One goal of Pi is to create a seamless experience for users and
developers. Developers need a way to connect with Pioneers and chat
with them to get valuable feedback, learn what their users want, and
grow app use. As a response to Developers’ requests and to support
this need, Developers of approved applications have the ability to
connect with Pioneers by opening a Public Chat Room in the Pi Chats.

## What Are They

For ease of use, each app-specific chat room will look and feel like a more general Pi Chat Room. However the moderation of these chat rooms will be executed by the Application Team themselves. In addition all chat rooms will be publicly searchable so Pioneers can find your chat room easily.

## Eligibility

To be eligible to open a chat room, an application must meet certain key requirements.

The application must:

- Be listed in the Ecosystem Application (Testnet or Mainnet)
- Abide by the developers Terms of Service
- Maintain active moderation that adheres to the Pi Terms of Service.

## Moderation

To accommodate the app-specific chat rooms, Community Apps will establish application teams themselves to maintain the moderation within their Pi Chat Room.

While the Pi Core Team will support the developers in their chat rooms with some moderation tools, all messages and moderation must adhere to the following guidelines:

- The [Pi Terms of Service](https://socialchain.app/tos)
- Messages Should be Free of:
  - Vulgarity
  - Personal attack
  - Advertising
  - Spamming/Flooding
  - Scam (potential)
  - Personal Information such as Names, Addresses
  - Wallet Passphrases
- The [Pi Developer Terms of Service](https://socialchain.app/developer_terms)

As chat rooms within Pi Network, we expect developers to maintain the standards of their community chat rooms, while applying their personal leadership and knowledge to maintain and support their users.

In addition to their own work, developer moderators will be supported with Pi Networks’ Auto-Moderation Tools, which will be enabled on all channels. These tools will automatically delete messages that contain certain banned words and unapproved links.

These Auto-Moderation tools are designed to help developer moderators be more efficient and more confident in running their channels free from spam, scams and abuse.

## Creating a Chat Room

Once an application is listed in the Ecosystem, the eligible app will receive a button “Create Chat Room” on the Developer Portal App Dashboard. Clicking on this button will begin the process to create your app’s chat room.

Next complete the required onboarding steps:

- Create a New Chat Room: The conversation name, the visibility of the app (Public), and the number of mining sessions a user must have completed in order to post in the conversation. This information is currently pre-filled with the possibility that it becomes editable in the future.
- Moderation Tools: This is a general overview of the Pi Core Team provided auto-moderation tools
- Permission Settings: This step will allow you to add members to your team to help moderate the content in the chat room. After chat room creation, permissions can only be changed from within the chat room itself.
- Terms of Service: Read and agree to the Terms and Service

Click “Create” to generate the conversation and be redirected to it.

## After Initial Chat Room Creation

- Add a Representative: chat room creators can go to the PiChat app, have your Representative post a message, and then tap and hold on their message to change their permissions.

- Remove a Representative: Chat room creators have a “Manage Chat Representatives” feature, accessed by clicking on the settings icon, on the feature page a chat room creator can see all of the current representative and remove representatives.


## Cost

With these chat rooms, developers will be better able to interface directly with users, creating their own environments to better deliver and improve utilities for Pioneers around the world.

We’re currently offering this feature as a free room for developers to connect with their community of users. Future iterations may include Pi payments to help developers create preferential chat rooms and balance system costs.
