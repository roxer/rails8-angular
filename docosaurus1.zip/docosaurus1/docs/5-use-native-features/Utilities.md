---
title: "Utilities"
sidebar_position: 2
---

### Share, Conversation, and Native Utilities

This guide demonstrates how to integrate the Pi SDK into
many application frameworks.
This example shows how to initialize the Pi SDK, authenticate a Pioneer, and
create a payment request inside a Pi app.

The `pi-sdk-js`
package
is part of the “Ten Minutes to Transactions” effort described in this
[video](https://www.youtube.com/watch?v=cIFqf1Z5pRM&t).

If you, or your GenAI agent, are planning to use the
Pi SDK modules in this documentation
for your app, it is highly suggested that you use this
package
rather than implement transaction processing by hand with the core Pi SDK. The three way handshake between client, server, and the Pi servers required is provded for you.

Note: Pi SDK authentication and payment features require the application to run inside the Pi Browser.

- **Share dialog:**`window.Pi.openShareDialog(title, message)`
- **Open conversation:**`window.Pi.openConversation(conversationId)`
- **Native features:**`window.Pi.nativeFeaturesList()` (lists available Pi-native methods)
- **Request permission:**`window.Pi.requestPermission(permissionName)`
- **Copy to clipboard:**`window.Pi.copyText(text)`
- **Open URL in system browser:**`window.Pi.openUrlInSystemBrowser(url)`

All utility methods return Promises that resolve with their respective results or reject if the feature is unavailable or fails. For the most up-to-date documentation on these methods, visit the [Pi Platform Docs](https://github.com/pi-apps/pi-platform-docs).
