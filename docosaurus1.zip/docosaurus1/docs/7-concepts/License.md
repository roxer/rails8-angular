---
title: "Licensing"
sidebar_position: 3
---

# Pi Open Source

PiOS stands for Pi Open Source, a Software License that allows Pi community developers to create and use open source applications and libraries within the Pi Ecosystem.

Applications that use the license are eligible for display within the PiOS repository.

To find out how to contribute, head over to the [PiOS repository](https://github.com/pi-apps/PiOS).

A list of registered applications and libraries is available in the [PiOS registry list](https://github.com/pi-apps/PiOS/blob/main/list.md).
