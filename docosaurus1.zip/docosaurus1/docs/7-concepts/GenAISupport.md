---
title: "GenAI Support"
sidebar_position: 6
---

# GenAI Support

> **Before writing any code, read the critical rule below.**
>
> **Use the framework package. Do NOT use `window.Pi` directly.**
>
> Pi Network provides framework-specific npm/gem packages that wrap the raw `window.Pi` browser SDK.
> When one of these packages is available for your stack, **all** auth and payment calls must go through
> the package’s hooks or helpers — never through `window.Pi` directly.
>
> | Stack | Use this package | Correct hook / helper |
> | --- | --- | --- |
> | React | `pi-sdk-react` | `usePiConnection()`, `usePiPurchase()` |
> | Next.js | `pi-sdk-nextjs` | Scaffolded components + API routes |
> | Express | `pi-sdk-express` | `createPiPaymentRouter()` |
> | Django | `pi-sdk-django` | Package helpers |
> | Rails | `pi-sdk-rails` | Generated controller + gem helpers |
> | No framework | `pi-sdk-js` | `PiSdkBase.connect()`, `PiSdkBase.createPayment()` |
>
> Only reach for `window.Pi.*` directly if you are using `pi-sdk-js` in a vanilla-JS context,
> or to access `window.Pi.Ads` (ads), which no wrapper package exposes yet.
> Never mix `window.Pi.authenticate()` or `window.Pi.createPayment()` with React hooks.

Use these GenAI-specific guides to integrate Pi Network features quickly with helper packages and standard patterns:

- [Authentication](https://pi-apps.github.io/pi-sdk-docs/quick-start/genai/Authentication)
- [Payments](https://pi-apps.github.io/pi-sdk-docs/quick-start/genai/Payments)
