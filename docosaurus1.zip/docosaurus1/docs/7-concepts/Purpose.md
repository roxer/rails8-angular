---
title: "Purpose"
sidebar_position: 2
---

# Pi Network SDK Documentation

## Purpose and Scope

This documentation portal provides a **unified view of the capabilities and integration patterns** across the Pi Network SDK stack for browser-based and modern JavaScript/TypeScript applications.

### Structure

- **Core foundation is the browser-delivered SDK:**
  - The canonical Pi SDK (`pi-sdk.js`): served at [https://sdk.minepi.com/pi-sdk.js](https://sdk.minepi.com/pi-sdk.js), loaded client-side via `<script>`, and exposed as `window.Pi` with all protocol features (authentication, payments, ads, wallet, native utilities, etc).
  - **This is the authoritative implementation for all Pi payment protocols and Pi Browser integrations.**
- **Additional support packages:**
  - `pi-sdk-js`: A TypeScript/ESM wrapper for testable, object-oriented usage across local apps and frameworks (Node, React, Vue, Next.js, etc). It simplifies safe access to the browser SDK.
  - `pi-sdk-react`: Framework-specific React components for drop-in usage and best-practices integration, built over `pi-sdk-js`.
  - `pi-sdk-express`: A combined frontend and backend reference implementation using Express as the backend framework and React frontend (uses `pi-sdk-react`).
  - `pi-sdk-nextjs`: A combined frontend and backend reference implementation using Next.js as the backend framework and React frontend (uses `pi-sdk-react`).
  - `pi-sdk-rails`: A combined frontend and backend reference implementation using Rails as the backend framework and provides both React and Stimulus frontend support (uses `pi-sdk-react`).

### Documentation Vision

- This documentation aims to provide a **clear, navigable, and unified entry point for all stakeholders** (app developers, integrators, maintainers) who need to:

  - Understand the true capabilities and integration points of the `window.Pi` browser SDK
  - Learn what the supporting npm packages provide (wrappers, helpers, UI integrations)
  - Find API references, usage patterns, and architectural diagrams

* * *
