---
title: "Launching on Pi Mainnet"
sidebar_position: 4
---

# Launching on Pi Mainnet

Once you have successfully deployed a testnet app, you can consider launching
on Pi Mainnet. To launch on mainnet, follow these steps:

1. Create a new mainnet app in the Pi Developer Portal and start completing
the app checklist.
2. Verify the app URL.
   - The URL cannot match a URL already verified by another Pi Developer Portal
     app.
   - If you need to adjust another app’s URL, first verify a new URL for that
     app before reusing its previous URL.
3. Generate an app wallet keypair for the “Connect App Wallet” step, then
apply for an Incoming Multisig Wallet for the U2A payment flow. The review
process can take time, but once the application is approved by the Pi Core
Team, you can connect the approved wallet to your app.
4. Similarly, if your app needs to process A2U payments (currently available
only for testnet apps and selected mainnet apps), you must submit an
application for an Outgoing Wallet.
