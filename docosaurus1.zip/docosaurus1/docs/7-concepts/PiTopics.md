---
title: "Pi Topics"
sidebar_position: 1
---

# Pi Topics

These sections cover many of the unique or special tools that the Pi App Platform offers to developers. Also covered are the blockchain topics that a developer should be familiar with.

## Table of contents

- [Pi Mainnet vs Pi Testnet](https://pi-apps.github.io/pi-sdk-docs/pitopics/MainVsTest)
- [Access Token](https://pi-apps.github.io/pi-sdk-docs/pitopics/AccessToken)
- [PiNet](https://pi-apps.github.io/pi-sdk-docs/pitopics/PiNet)
- [Public Chat Rooms](https://pi-apps.github.io/pi-sdk-docs/pitopics/ChatRooms)
- [Pi Payments](https://pi-apps.github.io/pi-sdk-docs/pitopics/PiPayments)
