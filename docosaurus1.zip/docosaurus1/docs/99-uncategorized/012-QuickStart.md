---
title: "Quick Start"
---

# Quick Start Packages

To accelerate your development process, we provide several “Quick Start” resources. These range from low-level libraries for custom integrations to full-stack boilerplates that can get you from a blank screen to a live transaction in minutes.

**Important for builders (including GenAI workflows):** Start with the official helper packages/gems and Quick Start templates whenever possible. They already implement the required authentication and payment flows, so you should extend them instead of re-creating those flows for each new app.

* * *

## Full-Stack Packages

These are complete, end-to-end reference applications designed to show exactly how the Frontend SDK and Backend APIs work together. They include pre-configured routes for authentication and the required “Double-Check” payment flow.

- [Next.js Quick Start](https://pi-apps.github.io/pi-sdk-docs/quick-start/NextJS)
- [Rails Quick Start](https://pi-apps.github.io/pi-sdk-docs/quick-start/Rails)
- [Django Quick Start](https://pi-apps.github.io/pi-sdk-docs/quick-start/Django)
- [Express Quick Start](https://pi-apps.github.io/pi-sdk-docs/quick-start/Express)

## Frontend Only

These packages provide frontend support for the foundational Pi SDK. They do
not provide backend support for the payment flow. You will need to provide
this functionality in your App’s backend with REST endpoints for approving
and completing transactions.

- [JavaScript Quick Start](https://pi-apps.github.io/pi-sdk-docs/quick-start/JavaScript)
- [React Quick Start](https://pi-apps.github.io/pi-sdk-docs/quick-start/React)

## SDK Integration Guide (Language Agnostic)

For developers using languages not officially supported by a standalone SDK (such as Python, Go, or PHP), we provide a comprehensive [**Integration Guide**](https://github.com/pi-apps/pi-sdk-integration-guide?tab=readme-ov-file#pi-network-sdk-integration-guide).

- **Focus:** Explains how to build your own bridge to the Pi Blockchain.
- **Contents:**
  - Instructions for signing and submitting blockchain transactions.
  - Structuring API calls to `api.minepi.com` for payment validation.
  - Best practices for App-to-User (A2U) payments, including handling sequence numbers.

## The Pi Sandbox

The Sandbox is a specialized testing environment that allows you to debug your app on a desktop browser rather than a mobile device. Instructions for setting up Sandbox access can be found in our [Getting Started guide](https://pi-apps.github.io/pi-sdk-docs/getting-started/Sandbox).

- **Developer Tooling:** Accessible via the Developer Portal, the Sandbox bridges your desktop environment to the Pi Browser.
- **Authorization:** Link your desktop session to your mobile Pi account to test authentication and payments in real-time.

* * *
