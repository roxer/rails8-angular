---
title: "Community Support"
sidebar_position: 2
---

# Community Support

The Pi community is one-of-a-kind. Having mined the Pi cryptocurrency through various contributions to the network and witnessed its development from the beginning, Pioneers are excited to offer support to its new members and help grow the Pi ecosystem.

## Discord

The fastest way to ask a question or get help is to join our Pi Ecosystem Discord server. Here, you will find many other developers who are also building on Pi and can assist you with any questions. The Pi Core Team is active in that server as well and can assist. To join the server, take a brief developer test within our Brainstorm App. To access the application, open the Pi Browser and go to `brainstorm.pinet.com` or click on the square Brainstorm logo on
the homepage.

## Pi App Chat

You can also send a message in the Developer chat room on the Pi App for help from other fellow Pi community developers or chat moderators. To subscribe to the Developer chat room, select the “Chat” icon from the home screen of the Pi app (or the “Chat” tile on the Pi Browser’s homepage). After authenticating, select the “Discover New Channels” tab near the top of the page to find a list of the other chat rooms. From this list, you can preview and join the Developer chat room. Once you join, it will now be shown in your regular list of chat rooms.

## Updates

Pi app’s home screen offers regular network updates, including any tech or ecosystem-related updates. Some of these updates are published on the
[Website](https://minepi.com/blog) blog as well. You can also follow us on
[X](https://x.com/PiCoreTeam) for announcements.

## Other Platforms

- Facebook: [PiCoreTeam](https://www.facebook.com/PiCoreTeam)
- Instagram: [@pi\\_network](https://www.instagram.com/pi_network)
- Telegram: [PiAnnouncements](https://t.me/PiAnnouncements)
- YouTube: [PiCoreTeam](https://www.youtube.com/c/PiCoreTeam)
- Medium: [pinetwork-official](https://pinetwork-official.medium.com/)
